from django.shortcuts import render,render_to_response,redirect,HttpResponseRedirect,reverse
from django.http import HttpResponse
from .models import Info,Product
from django.contrib.auth.models import User,auth
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.
def index(request):
    product=Product.objects.get(Id=1)
    context={
        'image':product.image,
    }
    return render(request,'dashboard/index.html',context)
# def login(request):
#     email=''
#     pwd =''
#     if request.method=='GET':
#         email= request.GET.get('email' ,'')
#         password= request.GET.get('password' ,''
#         #db connection
        

#         # con = c.connect(host='localhost',user='root',password='root',database='log')
       
#         cur = con.cursor()
#         cur.execute("select * from users where email='"+email+"' and pwd='"+pwd+"'")

#         # o = cur.fetchall()

#         if email !='' and pwd !='':
#                 return HttpResponse("https://www.w3schools.com")
#                 # return render_to_response("appor/index.html")
             
#         else:
#                 return HttpResponse('login fail')
def contact(request):

    if request.method=="GET":

        name=request.GET.get('name' ,'')
        email= request.GET.get('email' ,'')
        phone= request.GET.get('phone' ,'')
        desc= request.GET.get('desc' ,'')
        
        info=Info(name=name,email=email,phone=phone,desc=desc)
        info.save()
    return render(request,'dashboard/contact.html')



def about(request):
    return render_to_response('dashboard/about.html')
def returnpage(request):
    return render_to_response('dashboard/return.html')
# def login(request):
#     #  if request.method == 'POST':
#     #      username =request.POST['username']
#     #      password=request.POST['password']
#     #      user = authenticate(username=username,password=password)
#     #      if user is not None:

#     #         login_required(request,user)
#     #         return redirect('/')
#     #      else:

#     #         return render_to_response('dashboard/about.html')

#     #  else:

#          return render_to_response('dashboard/login.html')
    

def register(request):
    if request.method == 'POST':
        f = UserCreationForm(request.POST)
        if f.is_valid():
            f.save()
            messages.success(request, 'Account created successfully')
            return redirect('/')
 
    else:
        f = UserCreationForm()
 
    return render(request, 'dashboard/register.html', {'form': f})

def auth_view(request):
    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    user = auth.authenticate(username = username, password = password)      

    if user is not None:
        auth.login(request, user)
        return HttpResponseRedirect(reverse('index'))
    else:
        return HttpResponseRedirect('/dashboard/invalid')
def cart(request):
    return render_to_response('dashboard/cart.html')