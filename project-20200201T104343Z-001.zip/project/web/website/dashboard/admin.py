from django.contrib import admin

# Register your models here.
from .models import Info,Product
admin.site.register(Info)
admin.site.register(Product)