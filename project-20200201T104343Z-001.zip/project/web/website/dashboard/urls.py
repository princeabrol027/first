from django.urls import path
from dashboard import views
from django.conf import settings
from django.conf.urls.static import static
# from django.contrib.auth import views as auth_views
urlpatterns = [
    path('', views.index,name='index'),
    path('contact/', views.contact,name='contact'),
    path('about/', views.about,name='about'),
    path('register/', views.register,name='register'),
    path('login/',views.login,name='login'),
    path('cart/',views.cart,name='cart'),
    path('returnpage/',views.returnpage,name='returnpage'),
]