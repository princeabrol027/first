from django.db import models

# Create your models here.
class Info(models.Model):

    msg_id= models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    desc =models.TextField(max_length=500)

    def __Str__(self):
       return self.name

class Product(models.Model):

    Id= models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    category=models.TextField(max_length=30)
    image = models.ImageField(upload_to='images/')
    desc =models.TextField(max_length=500)

    def __Str__(self):
       return self.name