from flask import Flask,render_template,request
# import smtplib 
# import os
import csv
# from flask_mail import Message

# from flask_mail import Mail
# configer app
app = Flask(__name__)   
# mail=Mail(app)

# app.config['MAIL_SERVER']='smtp.gmail.com'
# app.config['MAIL_PORT'] = 465
# app.config['MAIL_USERNAME'] = 'princeabol05@gmail.com'
# app.config['MAIL_PASSWORD'] = 'abrol@123'
# app.config['MAIL_USE_TLS'] = False
# app.config['MAIL_USE_SSL'] = True
# app.config['MAIL_DEBUG'] = True
# mail = Mail(app)
# register stu
students=[]

@app.route("/")
def home():
    name=request.args.get("name", "USER")
    return render_template("home.html",foo=name)
@app.route("/register", methods=["post"])
def register():
    email=request.form.get("email")
    course=request.form.get("course")
    request.form.get("course")
    if not email  or not course:
        return"enter details bro"
    file = open('geek.csv','a') 
    writer= csv.writer(file)
    writer.writerow((request.form.get("email"),request.form.get("course"))) 
    
    file.close()

    
    return render_template("index.html")

